#!/usr/bin/env python3
"""
FOV 마커 + Nav Goal 노드
- /car_detected (Bool) 구독
- True 수신 시 카메라 FOV 삼각형 중점으로 NavigateToPose 전송
- RViz2 에 FOV 삼각형 마커 항상 표시
"""

import math

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from std_msgs.msg import Bool, ColorRGBA
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point
from nav2_msgs.action import NavigateToPose


class FovNavNode(Node):
    def __init__(self):
        super().__init__('fov_nav_node')

        # ── 파라미터 ──────────────────────────────────────────────────
        self.declare_parameter('cam_x',            -3.0)
        self.declare_parameter('cam_y',             2.5)
        self.declare_parameter('cam_yaw',           0.0)
        self.declare_parameter('fov_angle_deg',    40.0)
        self.declare_parameter('fov_distance',      1.5)
        self.declare_parameter('map_frame',        'map')
        self.declare_parameter('nav_namespace',    '/robot4')
        self.declare_parameter('goal_cooldown_sec', 10.0)

        p = self.get_parameter
        self.cam_x     = p('cam_x').value
        self.cam_y     = p('cam_y').value
        self.cam_yaw   = p('cam_yaw').value
        self.fov_angle = math.radians(p('fov_angle_deg').value)
        self.fov_dist  = p('fov_distance').value
        self.map_frame = p('map_frame').value
        nav_ns         = p('nav_namespace').value.rstrip('/')
        self._cooldown = p('goal_cooldown_sec').value

        self._detected    = False
        self._last_goal_t = 0.0
        self._navigating  = False

        # ── Nav2 액션 클라이언트 ──────────────────────────────────────
        action_name = f'{nav_ns}/navigate_to_pose'
        self._nav_client = ActionClient(self, NavigateToPose, action_name)
        self.get_logger().info(f'Nav2 액션 서버 대기: {action_name}')

        # ── 퍼블리셔 / 서브스크라이버 ─────────────────────────────────
        self._marker_pub = self.create_publisher(Marker, '/cam_fov_marker', 10)
        self.create_subscription(Bool, '/car_detected', self._on_detected, 10)
        self.create_timer(0.5, self._publish_fov)

        # FOV 중점 좌표 계산
        self._goal_x = self.cam_x + (self.fov_dist * 0.5) * math.cos(self.cam_yaw)
        self._goal_y = self.cam_y + (self.fov_dist * 0.5) * math.sin(self.cam_yaw)

        self.get_logger().info(
            f'cam=({self.cam_x},{self.cam_y})  yaw={math.degrees(self.cam_yaw):.1f}°  '
            f'goal=({self._goal_x:.2f},{self._goal_y:.2f})  nav_ns={nav_ns}'
        )

    # ── 감지 콜백 ──────────────────────────────────────────────────────
    def _on_detected(self, msg: Bool):
        if msg.data == self._detected:
            return
        self._detected = msg.data
        if self._detected:
            self._send_nav_goal()
        self._publish_fov()

    # ── Nav Goal ───────────────────────────────────────────────────────
    def _send_nav_goal(self):
        now = self.get_clock().now().nanoseconds / 1e9
        if now - self._last_goal_t < self._cooldown:
            self.get_logger().info(
                f'쿨다운 중 (남은: {self._cooldown - (now - self._last_goal_t):.1f}s)')
            return
        if self._navigating:
            self.get_logger().info('이미 이동 중 — 무시')
            return
        if not self._nav_client.server_is_ready():
            self.get_logger().error('Nav2 서버 미준비 — robot-nav를 먼저 실행하세요')
            return

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id    = self.map_frame
        goal_msg.pose.header.stamp       = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x    = self._goal_x
        goal_msg.pose.pose.position.y    = self._goal_y
        goal_msg.pose.pose.orientation.z = math.sin(self.cam_yaw / 2.0)
        goal_msg.pose.pose.orientation.w = math.cos(self.cam_yaw / 2.0)

        self._last_goal_t = now
        self._navigating  = True
        future = self._nav_client.send_goal_async(goal_msg)
        future.add_done_callback(self._goal_response_cb)
        self.get_logger().warn(
            f'[NAV] goal → ({self._goal_x:.2f}, {self._goal_y:.2f})')

    def _goal_response_cb(self, future):
        handle = future.result()
        if not handle.accepted:
            self.get_logger().error('[NAV] goal 거부됨')
            self._navigating = False
            return
        self.get_logger().info('[NAV] goal 수락 — 이동 중')
        handle.get_result_async().add_done_callback(self._result_cb)

    def _result_cb(self, future):
        self._navigating = False
        self.get_logger().warn('[NAV] 목표 도달 완료')

    # ── FOV 삼각형 마커 ────────────────────────────────────────────────
    def _publish_fov(self):
        m = Marker()
        m.header.frame_id = self.map_frame
        m.header.stamp    = self.get_clock().now().to_msg()
        m.ns     = 'cam_fov'
        m.id     = 0
        m.type   = Marker.TRIANGLE_LIST
        m.action = Marker.ADD
        m.pose.orientation.w = 1.0
        m.scale.x = m.scale.y = m.scale.z = 1.0
        m.color = ColorRGBA(r=1.0, g=0.1, b=0.0, a=0.5) if self._detected \
             else ColorRGBA(r=0.0, g=0.85, b=0.2, a=0.25)

        half = self.fov_angle / 2.0
        d    = self.fov_dist
        cx, cy, yaw = self.cam_x, self.cam_y, self.cam_yaw

        m.points = [
            Point(x=cx, y=cy, z=0.02),
            Point(x=cx + d * math.cos(yaw + half), y=cy + d * math.sin(yaw + half), z=0.02),
            Point(x=cx + d * math.cos(yaw - half), y=cy + d * math.sin(yaw - half), z=0.02),
        ]
        self._marker_pub.publish(m)


def main():
    rclpy.init()
    node = FovNavNode()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
        pass
    finally:
        rclpy.shutdown()


if __name__ == '__main__':
    main()
